// PaymentState interface
interface PaymentState {
    void handlePayment(PaymentContext context);
}

// PendingState class
class PendingState implements PaymentState {
    @Override
    public void handlePayment(PaymentContext context) {
        System.out.println("Payment is currently pending.");
        // Simulate some processing logic
        boolean paymentProcessed = processPayment(); // Mocking payment processing

        if (paymentProcessed) {
            context.setState(new CompletedState());
        } else {
            context.setState(new FailedState());
        }
    }

    private boolean processPayment() {
        // Simulate processing logic
        return Math.random() > 0.5; // Randomly succeed or fail
    }
}

// CompletedState class
class CompletedState implements PaymentState {
    @Override
    public void handlePayment(PaymentContext context) {
        System.out.println("Payment has been completed successfully.");
    }
}

// FailedState class
class FailedState implements PaymentState {
    @Override
    public void handlePayment(PaymentContext context) {
        System.out.println("Payment has failed. Please try again.");
    }
}

// PaymentContext class
class PaymentContext {
    private PaymentState state;

    public PaymentContext() {
        this.state = new PendingState(); // Initial state
    }

    public void setState(PaymentState state) {
        this.state = state;
    }

    public void processPayment() {
        state.handlePayment(this);
    }
}

// Main class
public class PaymentSystem {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();

        // Simulate payment processing
        for (int i = 0; i < 3; i++) {
            paymentContext.processPayment();
        }
    }
}
