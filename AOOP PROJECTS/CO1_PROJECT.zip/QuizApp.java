import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Question class to hold quiz questions
class Question {
    private String questionText;
    private String[] options;
    private int correctAnswerIndex;

    public Question(String questionText, String[] options, int correctAnswerIndex) {
        this.questionText = questionText;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options;
    }

    public boolean validateAnswer(int answerIndex) {
        return answerIndex == correctAnswerIndex;
    }
}

// Quiz class to manage the quiz
class Quiz {
    private List<Question> questions;

    public Quiz() {
        questions = new ArrayList<>();
    }

    public void addQuestion(Question question) {
        questions.add(question);
    }

    public void takeQuiz() {
        int score = 0;
        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            System.out.println("Q" + (i + 1) + ": " + question.getQuestionText());
            String[] options = question.getOptions();

            for (int j = 0; j < options.length; j++) {
                System.out.println((j + 1) + ". " + options[j]);
            }

            System.out.print("Your answer (1-" + options.length + "): ");
            int userAnswer = scanner.nextInt() - 1; // Convert to zero-based index

            if (question.validateAnswer(userAnswer)) {
                score++;
                System.out.println("Correct!\n");
            } else {
                System.out.println("Incorrect. The correct answer was: " + options[question.correctAnswerIndex] + "\n");
            }
        }

        System.out.println("Your final score: " + score + "/" + questions.size());
    }
}

// Main class to run the quiz application
public class QuizApp {
    public static void main(String[] args) {
        Quiz quiz = new Quiz();

        // Create quiz questions
        quiz.addQuestion(new Question("What is the capital of France?", 
            new String[]{"Berlin", "Madrid", "Paris", "Lisbon"}, 2));
        quiz.addQuestion(new Question("What is 2 + 2?", 
            new String[]{"3", "4", "5", "6"}, 1));
        quiz.addQuestion(new Question("Which planet is known as the Red Planet?", 
            new String[]{"Earth", "Mars", "Jupiter", "Saturn"}, 1));

        // Start the quiz
        quiz.takeQuiz();
    }
}
