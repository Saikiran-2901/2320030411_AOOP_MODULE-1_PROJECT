import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

// Functional interface for contact actions
@FunctionalInterface
interface ContactAction {
    void execute(ContactManager contactManager, Contact contact);
}

// Contact class with nested classes for different types
class Contact implements Comparable<Contact> {
    private String name;
    private String phoneNumber;
    private String email;

    public Contact(String name, String phoneNumber, String email) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public int compareTo(Contact other) {
        return this.name.compareTo(other.name);
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Phone: " + phoneNumber + ", Email: " + email;
    }

    // Nested classes for different contact types
    static class PersonalContact extends Contact {
        public PersonalContact(String name, String phoneNumber, String email) {
            super(name, phoneNumber, email);
        }
    }

    static class BusinessContact extends Contact {
        private String companyName;

        public BusinessContact(String name, String phoneNumber, String email, String companyName) {
            super(name, phoneNumber, email);
            this.companyName = companyName;
        }

        @Override
        public String toString() {
            return super.toString() + ", Company: " + companyName;
        }
    }
}

// ContactManager class to manage the list of contacts
class ContactManager {
    private List<Contact> contacts;

    public ContactManager() {
        contacts = new ArrayList<>();
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public void removeContact(Contact contact) {
        contacts.remove(contact);
    }

    public void updateContact(Contact oldContact, Contact newContact) {
        int index = contacts.indexOf(oldContact);
        if (index >= 0) {
            contacts.set(index, newContact);
        }
    }

    public List<Contact> searchByName(String name) {
        return contacts.stream()
                .filter(contact -> contact.getName().equalsIgnoreCase(name))
                .collect(Collectors.toList());
    }

    public List<Contact> searchByPhoneNumber(String phoneNumber) {
        return contacts.stream()
                .filter(contact -> contact.getPhoneNumber().equals(phoneNumber))
                .collect(Collectors.toList());
    }

    public void displayContacts() {
        contacts.stream()
                .sorted()
                .forEach(System.out::println);
    }
}

// Main class to run the contact management system
public class ContactManagementSystem {
    public static void main(String[] args) {
        ContactManager contactManager = new ContactManager();

        // Add contacts
        contactManager.addContact(new Contact.PersonalContact("Alice", "123-456-7890", "alice@example.com"));
        contactManager.addContact(new Contact.BusinessContact("Bob", "987-654-3210", "bob@business.com", "Business Inc."));
        contactManager.addContact(new Contact.PersonalContact("Charlie", "555-555-5555", "charlie@example.com"));

        // Display all contacts
        System.out.println("All Contacts:");
        contactManager.displayContacts();

        // Search by name
        System.out.println("\nSearch Results for 'Alice':");
        contactManager.searchByName("Alice").forEach(System.out::println);

        // Search by phone number
        System.out.println("\nSearch Results for '987-654-3210':");
        contactManager.searchByPhoneNumber("987-654-3210").forEach(System.out::println);

        // Update a contact
        System.out.println("\nUpdating Charlie's contact...");
        contactManager.updateContact(new Contact.PersonalContact("Charlie", "555-555-5555", "charlie@example.com"),
                new Contact.PersonalContact("Charlie", "555-555-1234", "charlie.new@example.com"));

        // Display updated contacts
        System.out.println("\nUpdated Contacts:");
        contactManager.displayContacts();

        // Remove a contact
        System.out.println("\nRemoving Alice's contact...");
        contactManager.removeContact(new Contact.PersonalContact("Alice", "123-456-7890", "alice@example.com"));

        // Display remaining contacts
        System.out.println("\nRemaining Contacts:");
        contactManager.displayContacts();
    }
}
